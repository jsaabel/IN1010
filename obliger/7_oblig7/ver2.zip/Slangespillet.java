public class Slangespillet{

  public static void main(String[] args) {

    Kontroll kontroll = new Kontroll();
  
  }
}
