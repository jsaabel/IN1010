class SlangeHode extends Element{

  public SlangeHode(int x, int y){
    super(x, y);
  }
}
